#include <stdio.h>

int main(void){
    printf("Hello CS137 2029 Cohort!\n");
    return 0;
}